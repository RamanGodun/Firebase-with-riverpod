// DO NOT EDIT. This is code generated via package:easy_localization/generate.dart

// ignore_for_file: constant_identifier_names

abstract class LocaleKeys {
  static const app_title = 'app.title';
  static const app = 'app';
  static const languages_switched_to_pl = 'languages.switched_to_pl';
  static const languages_switched_to_en = 'languages.switched_to_en';
  static const languages_switched_to_ua = 'languages.switched_to_ua';
  static const languages = 'languages';
  static const buttons_ok = 'buttons.ok';
  static const buttons_sign_in = 'buttons.sign_in';
  static const buttons_sign_up = 'buttons.sign_up';
  static const buttons_sign_out = 'buttons.sign_out';
  static const buttons_submitting = 'buttons.submitting';
  static const buttons_retry = 'buttons.retry';
  static const buttons_redirect_to_sign_up = 'buttons.redirect_to_sign_up';
  static const buttons_redirect_to_sign_in = 'buttons.redirect_to_sign_in';
  static const buttons_cancel = 'buttons.cancel';
  static const buttons_go_to_home = 'buttons.go_to_home';
  static const buttons_reset_password = 'buttons.reset_password';
  static const buttons_resend_email = 'buttons.resend_email';
  static const buttons = 'buttons';
  static const errors_page_not_found_title = 'errors.page_not_found_title';
  static const errors_page_not_found_message = 'errors.page_not_found_message';
  static const errors_error_dialog = 'errors.error_dialog';
  static const errors_firebase_title = 'errors.firebase_title';
  static const errors_firebase_message = 'errors.firebase_message';
  static const errors_errors_general_title = 'errors.errors_general_title';
  static const errors = 'errors';
  static const failure_firebase_doc_missing = 'failure.firebase.doc_missing';
  static const failure_firebase_wrong_password =
      'failure.firebase.wrong_password';
  static const failure_firebase_user_not_found =
      'failure.firebase.user_not_found';
  static const failure_firebase_invalid_credential =
      'failure.firebase.invalid_credential';
  static const failure_firebase_generic = 'failure.firebase.generic';
  static const failure_firebase_email_in_use = 'failure.firebase.email_in_use';
  static const failure_firebase_invalid_email =
      'failure.firebase.invalid_email';
  static const failure_firebase_missing_email =
      'failure.firebase.missing_email';
  static const failure_firebase_no_current_user =
      'failure.firebase.no_current_user';
  static const failure_firebase_operation_not_allowed =
      'failure.firebase.operation_not_allowed';
  static const failure_firebase_requires_recent_login =
      'failure.firebase.requires_recent_login';
  static const failure_firebase_too_many_requests =
      'failure.firebase.too_many_requests';
  static const failure_firebase_user_disabled =
      'failure.firebase.user_disabled';
  static const failure_firebase_weak_password =
      'failure.firebase.weak_password';
  static const failure_firebase_timeout = 'failure.firebase.timeout';
  static const failure_firebase = 'failure.firebase';
  static const failure_format_error = 'failure.format.error';
  static const failure_format = 'failure.format';
  static const failure_network_no_connection = 'failure.network.no_connection';
  static const failure_network_timeout = 'failure.network.timeout';
  static const failure_network = 'failure.network';
  static const failure_auth_unauthorized = 'failure.auth.unauthorized';
  static const failure_auth = 'failure.auth';
  static const failure_email_verification_timeout =
      'failure.email_verification.timeout';
  static const failure_email_verification = 'failure.email_verification';
  static const failure_plugin_missing = 'failure.plugin.missing';
  static const failure_plugin = 'failure.plugin';
  static const failure_unknown = 'failure.unknown';
  static const failure = 'failure';
  static const form_name = 'form.name';
  static const form_name_is_empty = 'form.name_is_empty';
  static const form_name_is_too_short = 'form.name_is_too_short';
  static const form_email = 'form.email';
  static const form_email_is_empty = 'form.email_is_empty';
  static const form_email_is_invalid = 'form.email_is_invalid';
  static const form_password = 'form.password';
  static const form_password_required = 'form.password_required';
  static const form_password_too_short = 'form.password_too_short';
  static const form_confirm_password = 'form.confirm_password';
  static const form_confirm_password_is_empty =
      'form.confirm_password_is_empty';
  static const form_confirm_password_mismatch =
      'form.confirm_password_mismatch';
  static const form = 'form';
  static const pages_home = 'pages.home';
  static const pages_home_message = 'pages.home_message';
  static const pages_profile = 'pages.profile';
  static const pages_change_password = 'pages.change_password';
  static const pages_reset_password = 'pages.reset_password';
  static const pages_verify_email = 'pages.verify_email';
  static const pages_sign_in = 'pages.sign_in';
  static const pages_sign_up = 'pages.sign_up';
  static const pages_reauthentication = 'pages.reauthentication';
  static const pages = 'pages';
  static const profile_name = 'profile.name';
  static const profile_id = 'profile.id';
  static const profile_email = 'profile.email';
  static const profile_points = 'profile.points';
  static const profile_rank = 'profile.rank';
  static const profile_error = 'profile.error';
  static const profile = 'profile';
  static const reset_password_header = 'reset_password.header';
  static const reset_password_sub_header = 'reset_password.sub_header';
  static const reset_password_success = 'reset_password.success';
  static const reset_password_remember = 'reset_password.remember';
  static const reset_password = 'reset_password';
  static const change_password_title = 'change_password.title';
  static const change_password_warning = 'change_password.warning';
  static const change_password_prefix = 'change_password.prefix';
  static const change_password_signed_out = 'change_password.signed_out';
  static const change_password_success = 'change_password.success';
  static const change_password = 'change_password';
  static const sign_in_header = 'sign_in.header';
  static const sign_in_sub_header = 'sign_in.sub_header';
  static const sign_in_forgot_password = 'sign_in.forgot_password';
  static const sign_in_not_member = 'sign_in.not_member';
  static const sign_in_button = 'sign_in.button';
  static const sign_in = 'sign_in';
  static const sign_up_sub_header = 'sign_up.sub_header';
  static const sign_up_already_have_account = 'sign_up.already_have_account';
  static const sign_up_button = 'sign_up.button';
  static const sign_up = 'sign_up';
  static const reauth_label = 'reauth.label';
  static const reauth_description = 'reauth.description';
  static const reauth_password_updated = 'reauth.password_updated';
  static const reauth_redirect_note = 'reauth.redirect_note';
  static const reauth_page = 'reauth.page';
  static const reauth = 'reauth';
  static const verify_email_sent = 'verify_email.sent';
  static const verify_email_not_found = 'verify_email.not_found';
  static const verify_email_check_prefix = 'verify_email.check_prefix';
  static const verify_email_spam = 'verify_email.spam';
  static const verify_email_check_suffix = 'verify_email.check_suffix';
  static const verify_email_ensure_correct = 'verify_email.ensure_correct';
  static const verify_email_unknown = 'verify_email.unknown';
  static const verify_email_or = 'verify_email.or';
  static const verify_email = 'verify_email';
  static const theme_light_enabled = 'theme.light_enabled';
  static const theme_dark_enabled = 'theme.dark_enabled';
  static const theme_amoled_enabled = 'theme.amoled_enabled';
  static const theme_light = 'theme.light';
  static const theme_dark = 'theme.dark';
  static const theme_amoled = 'theme.amoled';
  static const theme_choose_theme = 'theme.choose_theme';
  static const theme = 'theme';
}
