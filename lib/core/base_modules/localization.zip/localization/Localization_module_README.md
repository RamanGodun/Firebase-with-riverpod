# 🌍 Localization Module Guide

*Last updated: 2025-08-01*

----------------------------------------------------------------

## 🎯 GOAL

This module provides a **universal, modular, and scalable localization system** for Flutter apps, based on EasyLocalization. 
It encapsulates all localization logic, assets, context handling, DI integration, and language switching, 
supporting both Riverpod and Cubit/BLoC architectures **without code duplication**.

* 🏗️ Designed for Clean Architecture, multi-module projects, and production-grade localization 
    (incl. pluralization, context-based keys, custom loaders).
* 🌐 Enables seamless, robust translation handling, with full hot-reload and async language switching.



----------------------------------------------------------------

## 🚀 Quick Start

All localization and language switching is pre-configured.

### With Riverpod:

```dart
// main.dart
runApp(
  ProviderScope(
    parent: GlobalDIContainer.instance,
    child: AppLocalizationShell(),
  ),
);
```

### With Cubit/BLoC:

```dart
// main.dart
runApp(GlobalProviders(child: AppLocalizationShell()));
```

   * Then

```dart
// in main.dart
class AppLocalizationShell extends StatelessWidget {
  const AppLocalizationShell({super.key});

  @override
  Widget build(BuildContext context) {
    return LocalizationWrapper.configure(const AppRootViewShell());
  }
}

// In MaterialApp.router
MaterialApp.router(
  locale: context.locale,
  supportedLocales: context.supportedLocales,
  localizationsDelegates: context.localizationDelegates,
  // ...theme, navigation, overlays, etc
);
```

* Locale, supportedLocales, and delegates are always injected into MaterialApp using `context.*` for hot reload support.



----------------------------------------------------------------

## 📦 File Structure

* No tight coupling with app-level DI or state management. Only localization logic inside this module.
Each folder and file is strictly responsible for a single concern (core, assets, extensions, context, keys, etc). Example structure:

```
localization/
      .
      ├── core_of_module
      │   ├── init_localization.dart
      │   └── localization_wrapper.dart
      |
      ├── generated
      │   ├── codegen_loader.g.dart
      │   └── locale_keys.g.dart
      |
      ├── module_widgets
      │   ├── key_value_text_widget.dart
      │   ├── language_toggle_button
      │   │   ├── language_option.dart
      │   │   └── toggle_button.dart
      │   └── text_widget.dart
      |
      ├── utils
      │   ├── localization_logger.dart
      │   ├── string_x.dart
      │   └── text_from_string_x.dart
      |
      ├── without_localization_case
      |   ├── app_strings.dart
      |   └── fallback_keys.dart
      |
      └── Localization_module_README.md
```

   Also there is assets/translations filder with all locale JSON files



----------------------------------------------------------------

## 🧩 Architecture & Flow

> **Declarative, DI-agnostic, and robust — designed for production & multi-language growth.**

* **Single entrypoint:** All localization setup and context integration flows through `LocalizationWrapper.configure(...)`.
* **App-level injection:** Locale and delegates always injected at the highest possible widget (usually `MaterialApp.router`).
* **Generated keys:** Access all translations via generated constants (`LocaleKeys`) — never use hardcoded keys.
* **Hot reload & async switching:** Language/locale can be switched at runtime, with instant app reload. Supports both sync and async switching.
* **Fallbacks & custom resolvers:** Built-in fallback for missing translations; allows for custom resolution logic per app or module.
* **Pluralization/context:** Supports plural, gender, and context-based translations out-of-the-box.
* **Modular:** Localization is completely isolated and testable — no hidden app dependencies.

### Typical Localization Flow

1. **App bootstraps**, ensuring EasyLocalization is initialized before app launch.
2. **LocalizationWrapper** injects all context and translation delegates.
3. **MaterialApp.router** is configured with locale, supportedLocales, and delegates from context.
4. **Keys are used via LocaleKeys** everywhere in code (no magic strings).
5. **Language can be switched** at runtime — UI reloads automatically.

---

## 📝 Usage

### Accessing Translations

```dart
Text(LocaleKeys.profile_username.tr()),
Text(LocaleKeys.welcome_message.tr(args: [userName])),
```

### Switching Languages

```dart
// Switch to Ukrainian
context.setLocale(const Locale('uk', 'UA'));

// Switch to English (US)
context.setLocale(const Locale('en', 'US'));
```


### Pluralization & Contextualization

```dart
LocaleKeys.items_count.trPlural(count),
LocaleKeys.welcome_gender.tr(gender: user.gender),
```

* Use only generated keys — never hardcode translation keys or locale codes in the UI/business logic.

----------------------------------------------------------------

## ❓ FAQ

> **How do I add a new language?**

* Add a new JSON file (e.g. `fr-FR.json`) to `assets/translations/`.
* Add the new locale to `supportedLocales` in your bootstrap/init config.
* Add all translation keys to the new file.

---

> **How do I use custom pluralization or context?**

* Use `.trPlural()`, `.tr(gender: ...)`, or context-based `.tr(context: ...)` on LocaleKeys.
* See EasyLocalization docs for advanced syntax.

---

> **How do I unit-test translations?**

* Access all translations via generated keys (`LocaleKeys`).
* Use EasyLocalization's testing utilities, or mock context/locale for custom unit tests.

---

> **Can I lazy-load or split translation files?**

* Yes, EasyLocalization supports async/custom loaders and modular asset splits.
* Configure loaders in the module's init code if needed.

---

> **How do I add keys?**

* Add to all translation files and regenerate `locale_keys.g.dart`.
* Use keys everywhere for full compile-time safety.

----------------------------------------------------------------

## 💡 Best Practices

* Always use `LocaleKeys` — never hardcode translation keys in code.
* Inject localization context/delegates as high as possible in the widget tree (`MaterialApp.router`).
* Use extension methods for context locale access and switching — never call EasyLocalization statically in UI.
* Place all translation assets in `/assets/translations/` for easy scaling/maintenance.
* Always regenerate keys after adding translations.
* Prefer context-based pluralization and gender forms for natural language.
* Keep translation files clean and consistent across languages — avoid key drift or inconsistent structure.
* Document custom logic, pluralization rules, or loaders at module level.

---

### ⚠️ Avoid Pitfalls

* Never use hardcoded strings or keys for translations — always use `LocaleKeys`.
* Never inject locale, delegates, or supportedLocales manually — always use context extensions.
* Never couple localization logic with business/state logic — always keep this module isolated.
* Don’t add translation keys in only one language — always update all translation files in sync.
* Never override built-in EasyLocalization logic unless absolutely necessary.
* Avoid large, monolithic translation files — modularize by features for scale.

----------------------------------------------------------------

## ✅ Final Notes

* Fully modular: works with both Riverpod and Cubit/BLoC — no code duplication
* Highly testable: all logic and context extensions are isolated
* Built for scale: add/remove languages and keys with minimal friction
* Compile-time safety: all translation keys are generated and type-safe
* Production-ready: supports async switching, fallbacks, pluralization, and context
* Clean separation: all localization code, assets, and logic live in this module only


---
> **Happy coding! 🌍✨**
> Build robust, scalable Flutter apps for every market, language, and audience. Localization-first, architecture-first.

----------------------------------------------------------------
