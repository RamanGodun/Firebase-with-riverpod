import 'package:firebase_with_riverpod/core/base_modules/errors_handling/utils/extensions_on_failure/failure_diagnostics_x.dart';
import 'package:flutter/foundation.dart' show debugPrint;
import '../../../core_of_module/failure__entity.dart';
import 'errors_log_util.dart';

/// 🧩 [Failure] extensions — logging, diagnostics, analytics hooks
/// ✅ Track, debug, and log failures in structured way
//
extension FailureLogger on Failure {
  ///----------------------------

  /// 🐞 Logs failure to logger (e.g. Crashlytics)
  void log([StackTrace? stackTrace]) {
    ErrorsLogger.failure(this, stackTrace);
  }

  /// 🐛 Prints debug info with optional label
  Failure debugLog([String? label]) {
    final tag = label ?? 'Failure';
    debugPrint('[DEBUG][$tag] => $label — $message | status=$safeStatus');
    return this;
  }

  /// 📝 Summary string for quick diagnostics
  String get debugSummary => '[${runtimeType.toString()}] $label';

  /// 📊 Tracks failure event using analytics callback
  Failure track(void Function(String eventName) trackCallback) {
    trackCallback('failure_${safeCode.toLowerCase()}');
    return this;
  }

  //
}
